import { createContext, useContext, useState, useCallback, type ReactNode } from 'react';
import type { Order, OrderStatus, Address } from '@/types';
import { orders as initialOrders } from '@/data/mockData';
import { useAuth } from './useAuth';
import { useCart } from './useCart';

interface OrdersContextType {
  orders: Order[];
  createOrder: (shippingData: {
    email: string;
    firstName: string;
    lastName: string;
    address: string;
    city: string;
    phone: string;
    notes?: string;
  }) => Order;
  getUserOrders: () => Order[];
  getOrderById: (orderId: string) => Order | undefined;
  updateOrderStatus: (orderId: string, status: OrderStatus) => void;
  addOrder: (order: Order) => void;
}

const OrdersContext = createContext<OrdersContextType | undefined>(undefined);

export function OrdersProvider({ children }: { children: ReactNode }) {
  const { user } = useAuth();
  const { cart } = useCart();
  
  // Initialize orders from localStorage or use initial mock data
  const [orders, setOrders] = useState<Order[]>(() => {
    const storedOrders = localStorage.getItem('nouressalam_orders');
    if (storedOrders) {
      return JSON.parse(storedOrders);
    }
    // Store initial orders to localStorage
    localStorage.setItem('nouressalam_orders', JSON.stringify(initialOrders));
    return initialOrders;
  });

  // Save orders to localStorage whenever they change
  const saveOrders = useCallback((newOrders: Order[]) => {
    setOrders(newOrders);
    localStorage.setItem('nouressalam_orders', JSON.stringify(newOrders));
  }, []);

  const createOrder = useCallback((shippingData: {
    email: string;
    firstName: string;
    lastName: string;
    address: string;
    city: string;
    phone: string;
    notes?: string;
  }): Order => {
    const orderNumber = `NE-${Date.now().toString().slice(-6)}`;
    
    const shippingAddress: Address = {
      id: `addr-${Date.now()}`,
      userId: user?.id || 'guest',
      label: 'Shipping',
      street: shippingData.address,
      city: shippingData.city,
      state: '',
      zipCode: '',
      country: 'Morocco',
      isDefault: true,
    };

    const newOrder: Order = {
      id: `order-${Date.now()}`,
      orderNumber,
      userId: user?.id || 'guest',
      user: user || {
        id: 'guest',
        email: shippingData.email,
        firstName: shippingData.firstName,
        lastName: shippingData.lastName,
        role: 'customer',
        phone: shippingData.phone,
        isVerified: false,
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      },
      status: 'pending',
      paymentStatus: 'pending',
      items: cart.items.map(item => ({
        id: `oi-${Date.now()}-${item.id}`,
        productId: item.productId,
        product: item.product,
        quantity: item.quantity,
        price: item.price,
        total: item.total,
        vendorId: item.product.vendorId || 'vendor-1',
      })),
      subtotal: cart.subtotal,
      tax: cart.tax,
      shipping: cart.shipping,
      discount: cart.discount,
      total: cart.total,
      shippingAddress,
      billingAddress: shippingAddress,
      couponCode: cart.couponCode,
      isBulkOrder: false,
      notes: shippingData.notes,
      createdAt: new Date().toISOString(),
      updatedAt: new Date().toISOString(),
      timeline: [
        {
          id: `ot-${Date.now()}`,
          status: 'pending',
          description: 'Order placed',
          timestamp: new Date().toISOString(),
        }
      ],
    };

    const updatedOrders = [newOrder, ...orders];
    saveOrders(updatedOrders);
    
    return newOrder;
  }, [user, cart, orders, saveOrders]);

  const getUserOrders = useCallback(() => {
    if (!user) return [];
    return orders.filter(order => order.userId === user.id);
  }, [orders, user]);

  const getOrderById = useCallback((orderId: string) => {
    return orders.find(order => order.id === orderId || order.orderNumber === orderId);
  }, [orders]);

  const updateOrderStatus = useCallback((orderId: string, status: OrderStatus) => {
    const updatedOrders = orders.map(order => {
      if (order.id === orderId) {
        return {
          ...order,
          status,
          updatedAt: new Date().toISOString(),
          timeline: [
            ...(order.timeline || []),
            {
              id: `ot-${Date.now()}`,
              status,
              description: `Order ${status}`,
              timestamp: new Date().toISOString(),
            }
          ]
        };
      }
      return order;
    });
    saveOrders(updatedOrders);
  }, [orders, saveOrders]);

  const addOrder = useCallback((order: Order) => {
    const updatedOrders = [order, ...orders];
    saveOrders(updatedOrders);
  }, [orders, saveOrders]);

  return (
    <OrdersContext.Provider value={{
      orders,
      createOrder,
      getUserOrders,
      getOrderById,
      updateOrderStatus,
      addOrder,
    }}>
      {children}
    </OrdersContext.Provider>
  );
}

export function useOrders() {
  const context = useContext(OrdersContext);
  if (context === undefined) {
    throw new Error('useOrders must be used within an OrdersProvider');
  }
  return context;
}
